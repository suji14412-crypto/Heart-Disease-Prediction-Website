AI/ML PROJECT WEBSITE — BEGINNER-FRIENDLY FILE STRUCTURE

Files:
- index.html: the page content and sections.
- css/style.css: colors, fonts, layout, responsive design, and animations.
- js/script.js: mobile menu, navigation effects, tabs, form checks, and demo interaction.

HOW TO OPEN:
1. Extract this ZIP file.
2. Open the extracted AI-ML-Portfolio-Clean folder in VS Code.
3. Open index.html.
4. If you use the Live Server extension, right-click index.html and choose "Open with Live Server".
   Otherwise, double-click index.html to open it in your browser.

IMPORTANT PROJECT NOTE:
The prediction form in this website is a demonstration only. It uses simple JavaScript rules,
not a trained Logistic Regression model. It is not a medical tool. The page contains placeholders
for your name, GitHub profile, and LinkedIn profile; update those links before publishing.

The original page design and content have been preserved while moving the CSS and JavaScript
into separate files. No certificate folder was included in the uploaded ZIP, so add it later
if you want certificate images on this website.
